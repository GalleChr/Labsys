﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Dominio
{
    public class Tipo
    {
        #region Attributes
        public int Id { get; set; }
        public string Descrip { get; set; }

        #endregion

        #region Constructor

        public Tipo() { }

        #endregion
    }
}