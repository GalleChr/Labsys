﻿namespace Dominio
{
    public enum Estado
    {
        PENDIENTE, CONFIRMADO, CANCELADO
    }
}
